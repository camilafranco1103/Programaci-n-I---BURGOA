#Parcial-1
#Pedimos el nombre al usuario
name = input("Ingrese su nombre: ").capitalize()

while True:
    # Generamos el menu
    print(f"\nHola, {name}.\nOpciones del menú:")
    print("a. Juego de números.")
    print("b. Juego de palabras.")
    print("c. Salir.")

    option = input(f"{name} elija una opción (a, b, c): ")

    if option == 'a':
        numbers = []
        while True:
            number = int(input(f"{name} ingrese un número entero (ingrese 0 para terminar): "))
            #validamos que si ingresa cero termine
            if number == 0:
                break
            numbers.append(number)
        #separo en dos listas pares e impares
        even_numbers = [num for num in numbers if num % 2 == 0]
        odd_numbers = [num for num in numbers if num % 2 != 0]
        #Saco el mayor numero par
        if even_numbers:
            max_even_number = max(even_numbers)
            print(f"{name} el mayor número par es: {max_even_number}")
        else:
            print(f"{name} no se ingresaron números pares.")
        #promedio de numeros impares
        if odd_numbers:
            average_odd_numbers = sum(odd_numbers) / len(odd_numbers)
            print(f"El promedio de los números impares es: {average_odd_numbers}")
        else:
            print("No se ingresaron números impares.")

    elif option == 'b':
        phrase = input(f"{name}, ingrese una frase: ")
        vowels = {'a': 0, 'e': 0, 'i': 0, 'o': 0, 'u': 0}
        #cuento la cantidad de caracteres que se encuentran en la lista de vocales
        for character in phrase.lower():
            if character in vowels:
                vowels[character] += 1

        print("Cantidad de cada vocal en la frase:")
        for vowel, count in vowels.items():
            print(f"{vowel}: {count}")

    elif option == 'c':
        print(f"¡Hasta luego!{name}")
        break

    else:
        print("Opción no válida. Por favor, elija a, b o c.")
#Tmbien valido que si no ingresa una opcion valida vuelva a pedirselo
